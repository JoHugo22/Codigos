
package com.mycompany.trabajoenclase;

public class Trabajoenclase {

    public static void main(String[] args) {
       Persona persona1=new Persona("Samadi","Sanchez",19);
       persona1.setId("18291311313");
        System.out.println(persona1.getId());
    }
}
