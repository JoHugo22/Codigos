
package com.mycompany.trasporte;

public class Trasporte {

    public static void main(String[] args) {
        Moto motouno= new Moto("motocicleta", 3, "Suzuki");
        Auto autouno= new Auto("Buseta", 17, "Kia");
        
        motouno.conducir();
        System.out.println(motouno.marca);
        System.out.println(motouno.tipoVehiculo);
        System.out.println(motouno.pasajeros);
        autouno.conducir();
        System.out.println(autouno.marca);
        System.out.println(autouno.tipoVehiculo);
        System.out.println(autouno.pasajeros);
       
    }
}
